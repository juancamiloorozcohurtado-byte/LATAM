// server.js
const WebSocket = require("ws");

const PORT = process.env.PORT || 3000;
const wss = new WebSocket.Server({ port: PORT });

let players = {};

wss.on("connection", (ws) => {
  const id = Date.now().toString();
  players[id] = { x: 400, y: 300 };

  console.log(`Jugador conectado: ${id}`);

  ws.send(JSON.stringify({ type: "init", id, players }));

  ws.on("message", (msg) => {
    try {
      const data = JSON.parse(msg);
      if (data.type === "move") {
        players[id] = { x: data.x, y: data.y };
        broadcast({ type: "update", id, x: data.x, y: data.y });
      }
    } catch (e) {
      console.error("Error:", e);
    }
  });

  ws.on("close", () => {
    console.log(`Jugador desconectado: ${id}`);
    delete players[id];
    broadcast({ type: "remove", id });
  });
});

function broadcast(data) {
  const msg = JSON.stringify(data);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(msg);
    }
  });
}

console.log(`Servidor WebSocket corriendo en puerto ${PORT}`);
