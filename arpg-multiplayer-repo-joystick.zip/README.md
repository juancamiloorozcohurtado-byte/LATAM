
# Mini ARPG Multiplayer con Joystick

Versión con **joystick táctil + botón de habilidad** para móviles.  
Funciona en PC (WASD + L) y en móviles (joystick + botón).

---

## 🚀 Instrucciones

### 1. Subir a GitHub
- Crea un repositorio (ej: `arpg-multiplayer-joystick`).
- Sube los archivos: `server.js`, `package.json`, `index.html`, `README.md`.

### 2. Railway (Servidor)
- Conecta tu repo en [Railway](https://railway.app).
- Railway levantará `server.js`.
- Obtén una URL tipo:

```
wss://arpg-joystick-production.up.railway.app
```

### 3. Configurar cliente (index.html)
- Cambia en `index.html` la línea:

```js
const ws = new WebSocket("ws://localhost:3000");
```

por la URL de Railway.

### 4. GitHub Pages (Cliente)
- Activa Pages en el repo → obtén una URL pública.

### 5. Jugar
- PC: abre la URL, mueve con WASD, habilidad con L.
- Móvil: joystick en pantalla para mover, botón rojo para habilidad.

---

📌 Creado: 2025-08-19
